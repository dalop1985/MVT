from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Tios)
admin.site.register(Hermanos)
admin.site.register(Primos)
admin.site.register(Viven)
admin.site.register(Trabajo)